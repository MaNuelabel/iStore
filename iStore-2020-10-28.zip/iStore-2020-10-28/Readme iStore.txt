iStore Color
Color 
HEX #34AD5C, #AD3485;
RGB(52, 173, 92) | RGB(173, 52, 133)